<?php
require 'vendor/autoload.php';

if(!empty($_POST))
{ 
if(isset($_POST['name'],$_POST['gender'], $_POST['age'], $_POST['age'], $_POST['email']))
{ 

$name = $_POST['name'];
$gender = $_POST['gender'];
$age = $_POST['age'];
$email = $_POST['email'];
$phone = $_POST['phone']; 
$client = Elasticsearch\ClientBuilder::create()->build();

if ($client) {
echo 'Now connected  elastic search envronment '."<br>";


$indexed = $client->index([ 
'index' => 'children',
'type' => 'child',
'body' => [
'name' => $name,
'gender' => $gender,
'age' => $age
],
]);
}
}
}
?>
<div align="center">
<form action="index.php" method="post" >

<div>
Name:
<input type="text" name="name" ></div><br>
<div>
Gender:
<input type="text" name="gender"  ></div><br>
<div>
Age:
<input type="number" name="age" placeholder="number only" ></div><br>
<div>
Email:
<input type="email" name="email"  ></div><br>
<div>
Phone:
<input type="text" name="phone"  ></div><br>

<div>
<input type="submit" value="Add" class="btn"></div><br>

</form>
</div>